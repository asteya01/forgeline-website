# Freezeframe Privacy Policy

_Last updated: November 22, 2026_

**Freezeframe sends nothing anywhere unless you turn on AI assist, and then only the code you choose to send.**

- **Frames stay on your device.** Text recognition runs locally with a bundled OCR model (Tesseract, WebAssembly). No frame or image is ever uploaded.
- **No Freezeframe servers.** No accounts, no analytics, no telemetry.
- **AI assist is optional and off by default.** When you turn it on and press an AI button (Fix misreads, Explain, Make it better), the code text in that panel and its language are sent to the AI service you picked:
  - **Ollama** (the default): runs on your own computer at `localhost`, so the code never leaves your machine.
  - **An OpenAI-compatible service**: the code is sent to the address you entered, using your own API key, and that service's privacy policy applies.
  Nothing is sent until you press an AI button.
- **Your API key** is stored only in this browser's local extension storage on this device. It isn't synced and is sent only to the AI address you entered.
- **What's stored:** your captures (code, a small thumbnail, the page URL, video title and timestamp) in your browser's local extension storage, and your settings in Chrome sync storage (your API key is the exception: local only).
- **Deleting your data:** Popup → Settings → **Clear library**, or remove the extension.

## Permissions

| Permission | Why |
|---|---|
| Access to all sites | To add the freeze button to videos on any site, to take a screenshot of the tab when a video can't be read directly, and (only if you turn on AI assist) to reach the AI address you chose, such as Ollama on `localhost`. |
| `storage`, `unlimitedStorage` | Your library of captures and their thumbnails. |
| `offscreen` | Runs the OCR engine in a background page. |
